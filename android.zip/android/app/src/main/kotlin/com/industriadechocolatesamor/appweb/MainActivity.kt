package com.industriadechocolatesamor.appweb

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
